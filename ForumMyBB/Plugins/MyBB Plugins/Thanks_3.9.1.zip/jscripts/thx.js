/**
 *
 * Thanks Plugin
 * Developed by SaeedGH (SaeedGhMail@Gmail.com)
 * www.mybbhelp.ir
 * Last Edit By: Mohammad-Za - Sina Mojri - 2014-09-16
 */
var Thanks = {
	init: function()
	{
		$(document).ready(function(){
		});
	},
thx_common: function (response)
{
	try
	{
		var xml=response.responseXML;
		var remove=xml.getElementsByTagName('del').item(0).firstChild.data=="1";
		var lin=document.getElementById('a'+pid);
		if (remove) {
			var table = document.getElementById('thx' + pid);
			table.style.display = xml.getElementsByTagName('display').item(0).firstChild.data != 0 ?
				 '' : 'none';
			var list = document.getElementById('thx_list' + pid);
			list.innerHTML = xml.getElementsByTagName('list').item(0).firstChild.data;
			
			var title = document.getElementById('thx_title' + pid);
			title_title = xml.getElementsByTagName('title').item(0).firstChild.data;
			lin.ttle = title_title;
	}
		else 
		{
			lin.innerHTML="";
			lin.onclick=null;
			lin.href="";
			lin = null;
		}
	}
	catch(err)
	{
		alert("an Error had occured please contact administrator")
		alert(err);
	}
	finally
	{
		return lin;
	}
	
},
	
thx_action: function(response)
{
	var lin = Thanks.thx_common(response)
	if(lin!=null)
	{
        $("#thx_title" + pid).text(lin.ttle);
		lin.onclick= new Function("","return Thanks.rthx("+pid+");");
	}
},

rthx_action: function(response)
{
	var lin = Thanks.thx_common(response)
	if (lin!=null) 
	{
    $("#thx_title" + pid).text(lin.ttle);
	lin.onclick = new Function("", "return Thanks.thx(" + pid + ");");
	}
	
	
},
thx: function(id)
{
	pid=id;
	pb="pid="+pid;
		$.ajax(
		{
			url: 'xmlhttp.php?action=thankyou',
			type: 'post',
            data: 'pid='+pid,
	        complete: function (response)
{
Thanks.thx_action(response);
}
});
	return false;
},

rthx: function (id)
{
	pid=id;
		$.ajax(
		{
			url: 'xmlhttp.php?action=remove_thankyou',
			type: 'post',
            data: 'pid='+pid,
	        complete: function (response)
{
Thanks.rthx_action(response);
}
});
	return false;
},

};
Thanks.init();