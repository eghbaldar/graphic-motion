﻿<?php 
/**
 * Thanks Plugin - ‍‍‍‍‍‍‍‍‍persian - MyBBSkin.ir
 */

$l['thx_main'] = "تشکر";
$l['thx_givenby'] = "تشکر شده توسط:";
$l['thx_thanked_count'] = "{1} تشکر شده در {2} ارسال";
$l['thx_thank'] = "تشکر ها:";
$l['thx_remove'] = "حذف تشکر";
$l['thx_comma'] = " , ";
$l['thx_dir'] = "ltr";
?>