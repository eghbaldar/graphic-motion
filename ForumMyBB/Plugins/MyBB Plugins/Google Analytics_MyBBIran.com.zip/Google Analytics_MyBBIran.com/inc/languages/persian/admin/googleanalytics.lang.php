<?php
// Language file (english) for MyBB Plugin Google Analytics
// © 2014 - 2015 juventiner
// ---------------------------------------------------
// Last Update: 18.02.2015

$l['googleanalytics_info_name'] = 'تجزیه و تحلیل ترافیک گوگل';
$l['googleanalytics_info_desc'] = "افزونه گوگل آنالیز شامل API هست که در هدر انجمن قرار میگیرد. <br><i> پارسی شده توسط: <a href='http://dbookshop.ir' action='_blank' style='color: red;font-weight:bold;'>motorola30</a></strong> و <a href='http://mybbiran.com' action='_blank' style='color: red;font-weight:bold;'>MyBBIran.com</a></i>";

$l['googleanalytics_settings_name'] = 'تنظیمات تجزیه و تحلیل ترافیک گوگل';
$l['googleanalytics_settings_desc'] = 'در اینجا شما می توانید تنظیمات برای پلاگین گوگل آنالیز را ویرایش کنید.';

$l['googleanalytics_settings_status_name'] = 'فعالسازی تجزیه و تحلیل ترافک گوگل';
$l['googleanalytics_settings_status_desc'] = 'فعالسازی تجزیه و تحلیل ترافیک گوگل و نمایش در هدر توسط API.';
$l['googleanalytics_settings_url_name'] = 'شناسه تجزیه و تحلیل ترافیک گوگل';
$l['googleanalytics_settings_url_desc'] = 'لطفا شناسه ردیابی خود را اینجا وارد کنید. به عنوان مثال: "UA-7397872-4"';
?>