<?php
/**
*  Language English
*  Last Poster Avatar on Threads and Forums v 2.8.1
*
*  Sitio Web: http://forosmybb.es
*  Autor: Dark Neo - neogeoman@gmail.com
*/

//Desplegable List v2.0
$l['avatarep_user_profile'] = "نمایش مشخصات";
$l['avatarep_user_messages'] = "نمایش پیام";
$l['avatarep_user_sendpm'] = "فرستادن پ.خ";
$l['avatarep_user_sendemail'] = "فرستادن ایمیل";
$l['avatarep_user_threads'] = "نمایش موضوعات";
?>
