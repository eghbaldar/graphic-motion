<?php
/**
*  Language English
*  Last Poster Avatar on Threads and Forums v 2.8.1
*
*  Sitio Web: http://forosmybb.es
*  Autor: Dark Neo /mohammadmohammadi - neogeoman@gmail.com
*/

// Don't remove this values
$l['avatarep_name'] = "نمایش آواتار در بخش انجمن ها در صفخه اصلی";
$l['avatarep_descrip'] = "نمایش آواتار آخرین ارسال کننده و صاحب تاپیک در صفحه اصلی انجمن";
$l['avatarep_config'] = "تنظیمات پلاگین";

// Use this to change in your language phrases
$l['avatarep_title'] = "[پلاگین] آواتار در موضوعات و انجمن ها را در صفحه اصلی نشان میدهد ";
$l['avatarep_title_descrip'] = "تنظیمات این پلاگین (تنظیمات آواتار)";

$l['avatarep_power'] = "فعال / غیر فعال کردن پلاگین";
$l['avatarep_power_descrip'] = " انتخاب کنید اگر شما می خواهید  این افزونه فعال باشد";

$l['avatarep_forum'] = "آواتار در انجمن";
$l['avatarep_forum_descrip'] = "آواتار آخرین ارسال کننده را نشان میدهد";

$l['avatarep_thread_owner'] = "آواتار در موضوعات";
$l['avatarep_thread_owner_descrip'] = "آواتار صاحب تاپیک را نشان میدهد";

$l['avatarep_thread_lastposter'] = "آواتار در موضوعات";
$l['avatarep_thread_lastposter_descrip'] = "آواتار آخرین ارسال کننده را نشان میدهد";

$l['avatarep_thread_announcements'] = "آواتار در اطلاعیه";
$l['avatarep_thread_announcements_descrip'] = "نشان دادن آواتار در اطلاعیه کاربر";

$l['avatarep_search'] = "آواتار در جستجو";
$l['avatarep_search_descrip'] = "آواتار در نتایج جستجو را نشان میدهد";

$l['avatarep_menu'] = " بر روی منوی";
$l['avatarep_menu_descrip'] = " یک منوی باز شده در رویداد کلیک برای هر کاربر در آواتار خود نشان می دهد";

$l['avatarep_width'] = " ابعاد پنجره عرض آواتار";
$l['avatarep_width_descrip'] = "تنظیم عرض پنجره خود را با دف : 310";

$l['avatarep_height'] = "ابعاد پنجره ارتفاع آواتار ها";
$l['avatarep_height_descrip'] = "تنظیم ارتفاع پنجره خود را با دف : 120";

?>
