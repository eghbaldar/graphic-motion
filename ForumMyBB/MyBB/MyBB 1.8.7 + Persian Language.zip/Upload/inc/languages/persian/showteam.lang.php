<?php
/**
 * MyBB 1.8.7 Persian Language Pack
 * Copyright 2014 MyBBIran Group, All Rights Reserved
 *
 */

$l['nav_showteam'] = "تیم مدیریت انجمن";
$l['forum_team'] = "تیم مدیریت انجمن";
$l['moderators'] = "مدیران";
$l['username'] = "نام کاربری";
$l['lastvisit'] = "آخرین بازدید";
$l['email'] = "ایمیل";
$l['pm'] = "پیام خصوصی";
$l['mod_forums'] = "انجمن";
$l['online'] = "آنلاین";
$l['offline'] = "آفلاین";
$l['away'] = "غایب";

$l['group_leaders'] = "رهبر (ها)";
$l['group_members'] = "کاربر (ها)";

$l['no_members'] = "کاربری در این گروه وجود ندارد.";

$l['error_noteamstoshow'] = "مدیری برای نمایش وجود ندارد.";
