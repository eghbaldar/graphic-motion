<?php
/**
 * MyBB 1.8.7 Persian Language Pack
 * Copyright 2014 MyBBIran Group, All Rights Reserved
 *
 */

$l['all_forums'] = "تمامی انجمن‌ها";
$l['forum'] = "انجمن: ";
$l['posted_by'] = "ارسال کننده: ";
$l['on'] = "در";
$l['portal'] = "سردر";

