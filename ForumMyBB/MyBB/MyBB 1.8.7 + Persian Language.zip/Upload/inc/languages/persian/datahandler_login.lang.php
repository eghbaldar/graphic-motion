<?php
/**
 * MyBB 1.8.7 Persian Language Pack
 * Copyright 2014 MyBBIran Group, All Rights Reserved
 *
 */

$l['logindata_invalidpwordusername'] = "ترکیب نام کاربر و گذرواژه‌ی وارد شده اشتباه است. <br /><br />اگر گذرواژه‌ی خود را فراموش کرده‌اید، لطفاً <a href=\"member.php?action=lostpw\">یک گذرواژه‌ی جدید درخواست کنید</a>.";
$l['logindata_invalidpwordusernameemail'] = "ترکیب ایمیل و گذرواژه‌ی وارد شده اشتباه است. <br /><br />اگر گذرواژه‌ی خود را فراموش کرده‌اید، لطفاً <a href=\"member.php?action=lostpw\">یک گذرواژه‌ی جدید درخواست کنید</a>.";
$l['logindata_invalidpwordusernamecombo'] = "ترکیب نام کاربری و گذرواژه یا ایمیل و گذرواژه‌ی وارد شده اشتباه است. <br /><br />اگر گذرواژه‌ی خود را فراموش کرده‌اید، لطفاً <a href=\"member.php?action=lostpw\">یک گذرواژه‌ی جدید درخواست کنید</a>.";

$l['logindata_regimageinvalid'] = "کد امنیتی وارد شده اشتباه است. لطفاً کد را دقیقاً همان‌طور که در تصویر است وارد کنید.";
$l['logindata_regimagerequired'] = "به منظور ادامه‌ی فرآیند ورود، لطفاً کد امنیتی را وارد کنید. لطفاً کد را دقیقاً همان‌طور که در تصویر است وارد کنید.";
