<?php
/**
 * MyBB 1.8.7 Persian Language Pack
 * Copyright 2014 MyBBIran Group, All Rights Reserved
 *
 */

$l['php_info'] = "اطلاعات php";
$l['browser_no_iframe_support'] = "مرورگر شما iFrame‌ها را پشتیبانی نمی‌کند.";

