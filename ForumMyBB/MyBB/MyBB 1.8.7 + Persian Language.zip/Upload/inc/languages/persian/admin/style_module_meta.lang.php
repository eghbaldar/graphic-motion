<?php
/**
 * MyBB 1.8.7 Persian Language Pack
 * Copyright 2014 MyBBIran Group, All Rights Reserved
 *
 */
 
$l['templates_and_style'] = "قالب‌ها و پوسته‌ها";

$l['themes'] = "پوسته‌ها";
$l['templates'] = "قالب‌ها";

$l['can_manage_themes'] = "بتواند پوسته‌ها را مدیریت کند؟";
$l['can_manage_templates'] = "بتواند قالب‌ها را مدیریت کند؟ ";

