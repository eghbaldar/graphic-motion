<?php
/**
 * MyBB 1.8.7 Persian Language Pack
 * Copyright 2014 MyBBIran Group, All Rights Reserved
 *
 */
 
$l['home'] = "خانه";

$l['dashboard'] = "میز کار مدیر";
$l['preferences'] = "تنظیمات شخصی مدیر";
$l['mybb_credits'] = "سازندگان MyBB";

$l['add_new_forum'] = "افزودن انجمن جدید‌";
$l['search_for_users'] = "جستجوی کاربر";
$l['themes'] = "قالب‌ها";
$l['templates'] = "پوسته‌ها";
$l['plugins'] = "پلاگین‌ها";
$l['database_backups'] = "فایل‌های پشتیبان بانک اطلاعاتی";
$l['quick_access'] = "دسترسی سریع";
$l['online_admins'] = "مدیران آنلاین";
$l['ipaddress'] = "آدرس IP:";
$l['mybb_documentation'] = "مستندات MyBB";

