<?php
/**
 * MyBB 1.8.7 Persian Language Pack
 * Copyright 2014 MyBBIran Group, All Rights Reserved
 *
 */

$l['nav_sendthread'] = "ارسال موضوع به یک دوست";

$l['send_thread'] = "ارسال به یک دوست";
$l['recipient'] = "دریافت کننده: ";
$l['recipient_note'] = "در اینجا آدرس ایمیل دوست خود را وارد کنید.";
$l['subject'] = "عنوان: ";
$l['message'] = "پیام: ";
$l['error_nosubject'] = "شما باید یک عنوان برای پیام خود انتخاب کنید تا موضوع ارسال شود.";
$l['error_nomessage'] = "شما قبل از این که بتوانید این موضوع را به دوست خود ارسال نمایید باید یک پیام را برای دوست خود وارد نمایید.";


