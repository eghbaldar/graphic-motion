<?php
/**
 * MyBB 1.8
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Website: http://www.mybb.com
 * License: http://www.mybb.com/about/license
 *
 */

$l['hello'] = 'سلام جهان!';
$l['hello_add'] = 'افزودن';
$l['hello_add_message'] = 'افزودن پیام';
$l['hello_empty'] = 'هیچ پیامی یافت نشد.';
$l['hello_message_empty'] = 'کادر پیام نباید خالی باشد.';
$l['hello_done'] = 'پیام جدید با موفقیت افزوده شد.';