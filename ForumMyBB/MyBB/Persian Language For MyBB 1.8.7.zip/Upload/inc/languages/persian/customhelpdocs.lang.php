<?php
/**
 * MyBB 1.8.7 Persian Language Pack
 * Copyright 2014 MyBBIran Group, All Rights Reserved
 *
 */

/*
 * Custom Help Document Translation Format
 *
 * // Help Document {hid}
 * $l['d{hid}_name'] = "نام سند";
 * $l['d{hid}_desc'] = "توضیحات سند";
 * $l['d{hid}_document'] = "متن سند";
 */
