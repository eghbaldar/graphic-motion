<?php
/**
 * MyBB 1.8.7 Persian Language Pack
 * Copyright 2014 MyBBIran Group, All Rights Reserved
 *
 */
 
$l['error_no_connection'] = "خطایی در هنگام اتصال به سرور به وجود آمد: ";
$l['error_no_message'] = "پیامی‌مشخص نشده است یا به عبارتی وارد نشده است.";
$l['error_no_subject'] = "عنوانی مشخص نشده است یا به عبارتی وارد نشده است.";
$l['error_no_recipient'] = "هیچ دریافت کننده‌ای مشخص نشده است یا به عبارتی وارد نشده است.";
$l['error_not_sent'] = "خطایی به هنگام ارسال پیام از طریق پیام رسانی php به‌وجود آمد.";
$l['error_status_missmatch'] = "آمار انجمن با نتیجه‌ی هم خوانی ندارد، در حال بازگشت:  ";
$l['error_data_not_sent'] = "این داده نمی‌تواند به سرور ارسال شود:  ";
$l['error_occurred'] = "یک یا چند خطا به وجود آمد. لطفاً قبل از ادامه، خطا‌های زیر را اصلاح کنید . <br />";
