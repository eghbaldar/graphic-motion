<?php
/**
 * MyBB 1.8.7 Persian Language Pack
 * Copyright 2014 MyBBIran Group, All Rights Reserved
 *
 */

$l['redirect_threadrated'] = "سپاس گزاریم، شما با موفقیت به موضوع امتیاز دادید. اکنون به موضوع مورد نظر باز خواهید گشت.";

$l['error_invalidrating'] = "شما یک امتیاز نامعتبر برای این موضوع انتخاب کرده‌اید. لطفاً بازگردید و دوباره امتحان کنید.";
$l['error_alreadyratedthread'] = "پوزش! شما قبلاً به این موضوع امتیاز داده‌اید.";
$l['error_cannotrateownthread'] = "پوزش! شما نمی‌توانید به موضوع ایجاد شده توسط خودتان امتیاز دهید.";

$l['rating_votes_average'] = "{1} رأی - میانگین امتیازات:  {2} از 5";
$l['one_star'] = "1 ستاره از 5 ستاره";
$l['two_stars'] = "2 ستاره از 5 ستاره";
$l['three_stars'] = "3 ستاره از 5 ستاره";
$l['four_stars'] = "4 ستاره از 5 ستاره";
$l['five_stars'] = "5 ستاره از 5 ستاره";
$l['rating_added'] = "امتیاز شما اضافه گردید!";
