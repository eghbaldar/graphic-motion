<?php
/**
 * MyBB 1.8.7 Persian Language Pack
 * Copyright 2014 MyBBIran Group, All Rights Reserved
 *
 */

$l['forums_and_posts'] = "انجمن‌ها و ارسال‌ها";

$l['forum_management'] = "مدیریت انجمن‌ها";
$l['forum_announcements'] = "اطلاعیه‌های انجمن";
$l['moderation_queue'] = "صف مدیریت";
$l['attachments'] = "پیوست‌ها";

$l['can_manage_forums'] = "بتواند انجمن‌ها را مدیریت کند؟";
$l['can_manage_forum_announcements'] = "بتواند اطلاعیه‌های انجمن را مدیریت کند؟";
$l['can_moderate'] = "بتواند ارسال‌ها، موضوعات و پیوست‌ها را مدیریت کند؟";
$l['can_manage_attachments'] = "بتواند پیوست‌ها را مدیریت کند؟";

