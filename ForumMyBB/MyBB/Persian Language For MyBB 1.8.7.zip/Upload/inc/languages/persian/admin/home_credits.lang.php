<?php
/**
 * MyBB 1.8.7 Persian Language Pack
 * Copyright 2014 MyBBIran Group, All Rights Reserved
 *
 */

$l['mybb_credits'] = "سازندگان MyBB";
$l['mybb_credits_description'] = "افرادی که در ساختن و توسعه‌ی MyBB زمان گذاشته، و در این مسیر تلاش کرده‌اند.";
$l['about_the_team'] = "درباره‌ی گروه";
$l['check_for_updates'] = "بررسی برای به‌روزرسانی‌های جدید";
$l['error_communication'] = "خطایی در دریافت آخرین فهرست سازندگان MyBB به وجود آمد. لطفاً دقایقی دیگر، دوباره تلاش کنید.";
$l['no_credits'] = "هیچ سازنده‌ای ثبت نشده است. <a href=\"index.php?module=home-credits&amp;fetch_new=1\">بررسی برای آخرین تغییرات</a>.";
$l['success_credits_updated'] = 'کَش سازندگان MyBB با موفقیت به‌روزرسانی شد.';

