<?php
/**
 * MyBB 1.8.7 Persian Language Pack
 * Copyright 2014 MyBBIran Group, All Rights Reserved
 *
 */

// Help Section 1
$l['s1_name'] = "نگهداری کاربر";
$l['s1_desc'] = "دستورالعمل کاری برای نگهداری حساب کاربری در انجمن.";

// Help Section 2
$l['s2_name'] = "ارسال پست";
$l['s2_desc'] = "ایجاد موضوع، ارسال پاسخ و استفاده‌ی اساسی از این انجمن.";
