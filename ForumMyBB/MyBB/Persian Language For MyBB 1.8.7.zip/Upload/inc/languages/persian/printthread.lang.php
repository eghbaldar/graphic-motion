<?php 
/**
 * MyBB 1.8.7 Persian Language Pack
 * Copyright 2014 MyBBIran Group, All Rights Reserved
 *
 */

$l['forum'] = "انجمن: ";
$l['printable_version'] = "نسخه‌ی قابل چاپ";
$l['pages'] = "صفحه‌ها: ";
$l['thread'] = "موضوع: ";
